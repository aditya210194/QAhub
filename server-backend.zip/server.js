require('dotenv').config(); // Load environment variables
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const helmet = require('helmet'); // Security headers
const rateLimit = require('express-rate-limit'); // Rate limiting
const Joi = require('joi'); // Validation

const app = express();

// Middleware
app.use(cors()); // Enable Cross-Origin Resource Sharing (CORS)
app.use(bodyParser.json()); // Parse incoming JSON requests
app.use(helmet()); // Add security headers

// Rate Limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP, please try again after 15 minutes.',
});
app.use(limiter);

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
    .then(() => console.log('MongoDB connected'))
    .catch((err) => console.error('Error connecting to MongoDB:', err));

// Define the Schema
const contactSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true },
    message: { type: String, required: true },
});

const Contact = mongoose.model('Contact', contactSchema);

// Joi Validation Schema
const contactValidationSchema = Joi.object({
    name: Joi.string().pattern(/^[a-zA-Z\s]+$/).required().messages({
        'string.empty': 'Name is required.',
        'string.pattern.base': 'Name can only contain letters and spaces.',
    }),
    email: Joi.string().email().required().messages({
        'string.empty': 'Email is required.',
        'string.email': 'Please enter a valid email address.',
    }),
    message: Joi.string().min(10).required().messages({
        'string.empty': 'Message is required.',
        'string.min': 'Message should be at least 10 characters long.',
    }),
});

// POST Route for Submitting the Form
app.post('/submitContactForm', async (req, res) => {
    const { name, email, message } = req.body;

    // Validate Request Body with Joi
    const { error } = contactValidationSchema.validate({ name, email, message }, { abortEarly: false });

    if (error) {
        return res.status(400).json({
            success: false,
            errors: error.details.map((err) => err.message),
        });
    }

    try {
        const newContact = new Contact({ name, email, message });
        await newContact.save();
        console.log('Form submitted successfully:', { name, email, message });
        res.status(201).json({ success: true, message: 'Form submitted successfully' });
    } catch (err) {
        console.error('Error saving to MongoDB:', err);
        res.status(500).json({ error: 'Error saving data to database', details: err.message });
    }
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
